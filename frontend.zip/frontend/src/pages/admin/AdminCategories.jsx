import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api from '../../api/client.js';
import ConfirmDialog from '../../components/admin/ConfirmDialog.jsx';

export default function AdminCategories() {
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [keyword, setKeyword] = useState('');
  const [deleteTarget, setDeleteTarget] = useState(null);

  const loadData = () => {
    setLoading(true);
    api.get('/admin/categories')
      .then((res) => setCategories(Array.isArray(res.data) ? res.data : res.data?.data || []))
      .catch(() => setError('Gagal memuat data dari server.'))
      .finally(() => setLoading(false));
  };

  useEffect(() => { loadData(); }, []);

  const filtered = categories.filter((c) => (c.name || '').toLowerCase().includes(keyword.toLowerCase()));

  const handleDelete = async () => {
    if (!deleteTarget) return;
    try {
      await api.delete(`/categories/${deleteTarget.id}`);
      setDeleteTarget(null);
      loadData();
    } catch (err) {
      alert(err.response?.data?.message || 'Gagal menghapus data.');
    }
  };

  return (
    <div>
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-[#0284C7]">Kategori</h2>
          <p className="text-[#414844]/80 text-sm mt-1">Kelola kategori tenaga ahli/konten.</p>
        </div>
        <Link
          to="/admin/kategori/tambah"
          className="flex items-center gap-2 bg-[#0284C7] text-white px-4 py-2.5 rounded-lg text-sm font-bold hover:bg-[#0369A1] transition-colors"
        >
          <span className="material-symbols-outlined text-[20px]">add</span>
          Tambah Kategori
        </Link>
      </div>

      {error && <div className="mb-4 bg-[#FFDAD6] text-[#93000A] text-sm rounded-lg p-3">{error}</div>}

      <div className="bg-white rounded-xl border border-[#0284C7]/15 shadow-sm overflow-hidden">
        <div className="p-5 border-b border-[#0284C7]/15">
          <input
            value={keyword}
            onChange={(e) => setKeyword(e.target.value)}
            placeholder="Cari nama kategori..."
            className="w-full max-w-sm px-4 py-2 text-sm border border-[#0284C7]/30 rounded-lg focus:ring-[#0284C7] focus:border-[#0284C7]"
          />
        </div>
        <table className="w-full text-left text-sm">
          <thead>
            <tr className="bg-[#0284C7]/5 text-[#414844]">
              <th className="px-6 py-3">Nama</th>
              <th className="px-6 py-3">Icon</th>
              <th className="px-6 py-3">Urutan</th>
              <th className="px-6 py-3">Aksi</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[#0284C7]/10">
            {loading ? (
              <tr><td colSpan={4} className="px-6 py-8 text-center text-[#414844]/70">Memuat data...</td></tr>
            ) : filtered.length === 0 ? (
              <tr><td colSpan={4} className="px-6 py-8 text-center text-[#414844]/70">{keyword ? `Tidak ditemukan hasil untuk "${keyword}"` : 'Tidak ada data.'}</td></tr>
            ) : (
              filtered.map((c) => (
                <tr key={c.id} className="hover:bg-[#0284C7]/5">
                  <td className="px-6 py-4 font-semibold text-[#0284C7]">{c.name}</td>
                  <td className="px-6 py-4 text-[#414844]/80">{c.icon || '-'}</td>
                  <td className="px-6 py-4 text-[#414844]/80">{c.order}</td>
                  <td className="px-6 py-4 flex gap-2">
                    <Link to={`/admin/kategori/${c.id}/edit`} className="text-[#0284C7] hover:underline text-xs font-bold">Edit</Link>
                    <button onClick={() => setDeleteTarget(c)} className="text-[#B3261E] hover:underline text-xs font-bold">Hapus</button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      <ConfirmDialog
        open={!!deleteTarget}
        onCancel={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
        message={`Yakin ingin menghapus kategori "${deleteTarget?.name}"?`}
      />
    </div>
  );
}